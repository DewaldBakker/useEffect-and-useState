import { useState,useEffect } from 'react';
import './App.css';
import UseStateP from './Practice/UseStateP';
import UseEffect from './Practice/UseEffect';
import Data from './Practice/Data.jsx'
import Display from './Practice/Display';
function App() {
      const [count,setcount]=useState(0);
      {/*use state*/}
      const [Number,setNumber]=useState(0);//text box number

      
      {/*use Effect*/}
      const Students=[
        {id:1,name:'Alice',course:'WPR161',year:2},
        {id:2,name:'Alex',course:'PRG161',year:3},
        {id:3,name:'Anne',course:'DBD161',year:1},
        {id:4,name:'Alisha',course:'WPR161',year:3},
        {id:5,name:'Ant',course:'INL161',year:2}
      ]
      const [Index, setIndex]= useState(0);
      const [FeatureStudent, setFeatureStudent]= useState(null);
      
      function NextStudent(){
        setIndex((prev)=>(prev+1) % Students.length)
      }
      useEffect(()=>{
        setFeatureStudent(Students[Index])
      },[Index])
  return (
    <div>
      {/*use state*/}
    <div  style={{ display: "flex", gap: "10px" }}>
      {/*Double the following value*/}
      <input
        type="text"
        onChange={(e) => setNumber(e.target.value)}
        placeholder={Number}
        style={{
            padding: "10px",
            fontSize: "16px",
            width: "200px",
            borderBlockColor:'blue',
            paddingBlock:'10px'
          }}/>
      <button style={{
        gap:'10px',
            padding: "10px",
            fontSize: "16px",
            width: "200px",
            backgroundColor:'blue',
            color:'white'
          }}onClick={(()=>setNumber(Number*2))}>Double</button>
      </div>
      <p>Your number is now {Number}</p>
      {/*Count the amount you clicked*/}
      <p>You clicked {count} time(s)</p>
      <button onClick={()=>setcount(count+1)}>Click me</button>
    {/*use Effect*/}
    <div className='app'>
      <div className='card'>
        <h1>Featured Student</h1>
        <button onClick={NextStudent}>Next Student</button>
        {/*Portfile is only printed if the value in student is not null*/}
        {FeatureStudent && (
          <div className='profile'>
          <h2>
            {FeatureStudent.name}            
          </h2>
          <p>
            <strong>
              <b>Course: {FeatureStudent.course}</b>
            </strong>
            <br/>
            <strong>
              <b>Year: {FeatureStudent.year}</b>
            </strong>
          </p>
        </div>
      )}
      </div>
    </div>
    <UseStateP/>
    <UseEffect/>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr'}}>
      {Data.map((s)=>(
          <Display {...s}/>
        ))}
        </div>
    </div>
  );
}

export default App;
