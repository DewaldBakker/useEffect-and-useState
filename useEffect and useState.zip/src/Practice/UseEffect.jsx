import React from 'react'
import { useEffect,useState } from 'react'
import Display from './Display'
import Students from './Data'
function UseEffect() {
    const[Index,setIndex]=useState(0)
    const[Info,setInfo]=useState(null)

    function Next(){
      setIndex((prev)=>(prev+1) % Students.length)
    }

    useEffect(()=>{
      setInfo(Students[Index])
    },[Index])

  return (
    <div className='app'>
      <div className='card'>
        <div  className='profile'>
          <h1>Student info</h1>
          {Info &&(
          <Display {...Info}/>
          )}
        <button onClick={Next}>Next</button>
        </div>
        </div>
    </div>
  )
}

export default UseEffect