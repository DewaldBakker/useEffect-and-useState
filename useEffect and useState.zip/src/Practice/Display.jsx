import React from 'react'

function Display({id,name,course,year}) {
  return (
    <div>
        <div style={{paddingBottom:'20px'}}>
            <div>Id number: {id}</div>
            <div>Name: {name}</div>
            <div>Course: {course}</div>
            <div>year: {year}</div>
        </div>
    </div>
  )
}

export default Display