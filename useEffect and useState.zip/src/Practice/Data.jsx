const Students=[
    {id:1,name:'Alice',course:'WPR161',year:2},
    {id:2,name:'Alex',course:'PRG161',year:3},
    {id:3,name:'Anne',course:'DBD161',year:1},
    {id:4,name:'Alisha',course:'WPR161',year:3},
    {id:5,name:'Ant',course:'INL161',year:2}
]
export default Students