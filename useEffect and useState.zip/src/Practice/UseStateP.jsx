import { useState } from 'react'
import React from 'react'


function UseStateP() {
   const [Count,setCount]=useState(0);
  return (
    <div>
        <button onClick={()=>setCount(Count+1)}>Count</button>
        <div>You pressed the button {Count} times</div>
    </div>
  )
}

export default UseStateP